<?php 
include 'includes/header.php';
include 'config/database.php';

// Logika hapus akun sendiri jika tombol diklik oleh user yang sedang login
if (isset($_GET['hapus_akun']) && isset($_SESSION['user_id'])) {
    $uid = intval($_SESSION['user_id']);
    // Pastikan admin utama tidak terhapus tidak sengaja jika diinginkan, atau hapus langsung
    mysqli_query($conn, "DELETE FROM users WHERE id = $uid");
    session_unset();
    session_destroy();
    echo "<script>alert('Akun Anda berhasil dihapus.'); window.location='index.php';</script>";
    exit;
}
?>
<section class="relative bg-gradient-to-r from-gray-900 via-black to-gray-900 py-20 border-b border-gray-800">
    <div class="max-w-7xl mx-auto px-4 text-center">
        <h1 class="text-4xl sm:text-6xl font-extrabold text-white tracking-tight mb-4">
            Koleksi Kendaraan <span class="text-amber-400">Mahakarya Dunia</span>
        </h1>
        <p class="text-lg text-gray-400 max-w-2xl mx-auto mb-8">
            Temukan mobil impian eksklusif Anda dengan standar kemewahan tertinggi dan performa tanpa kompromi.
        </p>
        <a href="produk.php" class="bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold px-8 py-3 rounded-xl transition shadow-lg">Jelajahi Katalog</a>
    </div>
</section>

<!-- Tambahan baris info akun & tombol hapus akun jika user login -->
<?php if (isset($_SESSION['user_id']) && $_SESSION['role'] !== 'admin'): ?>
    <div class="bg-gray-900 border-b border-gray-800 py-3 px-6 text-center text-sm text-gray-400">
        <span>Status Akun: <strong class="text-amber-400"><?= htmlspecialchars($_SESSION['username']) ?></strong></span> | 
        <a href="index.php?hapus_akun=1" onclick="return confirm('Apakah Anda yakin ingin menghapus akun Anda secara permanen?')" class="text-red-400 hover:underline ml-2 font-semibold">Hapus Akun Saya</a>
    </div>
<?php endif; ?>

<main class="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
    <h2 class="text-2xl font-bold text-white mb-8 border-l-4 border-amber-400 pl-3">Unit Unggulan Terbaru</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php
        $result = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC LIMIT 3");
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $img_path = "uploads/produk/" . $row['gambar'];
                ?>
                <div class="bg-[#1f2833] rounded-xl overflow-hidden shadow-xl border border-gray-800 flex flex-col justify-between">
                    <div>
                        <div class="h-48 bg-gray-700 flex items-center justify-center relative overflow-hidden">
                            <?php if (!empty($row['gambar']) && file_exists($img_path)): ?>
                                <img src="<?= htmlspecialchars($img_path) ?>" alt="<?= htmlspecialchars($row['nama_mobil']) ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <i class="fa-solid fa-car text-5xl text-gray-500"></i>
                            <?php endif; ?>
                            <span class="absolute top-2 right-2 bg-amber-500 text-gray-900 text-xs font-bold px-2 py-1 rounded z-10"><?= htmlspecialchars($row['kategori']) ?></span>
                        </div>
                        <div class="p-5">
                            <h3 class="text-xl font-bold text-white mb-2"><?= htmlspecialchars($row['nama_mobil']) ?></h3>
                            <p class="text-gray-400 text-sm mb-4 line-clamp-2"><?= htmlspecialchars($row['deskripsi']) ?></p>
                        </div>
                    </div>
                    <div class="p-5 pt-0 flex items-center justify-between border-t border-gray-700/50 mt-4">
                        <span class="text-amber-400 font-bold">Rp <?= number_format($row['harga'], 0, ',', '.') ?></span>
                        <a href="detail.php?id=<?= $row['id'] ?>" class="bg-amber-500 hover:bg-amber-600 text-gray-900 font-semibold px-4 py-2 rounded-lg text-xs transition">Detail</a>
                    </div>
                </div>
                <?php
            }
        } else {
            echo '<p class="text-gray-400 col-span-full text-center py-10">Belum ada unit unggulan.</p>';
        }
        ?>
    </div>
</main>
<?php include 'includes/footer.php'; ?>