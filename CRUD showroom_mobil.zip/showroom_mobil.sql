-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 29, 2026 at 10:46 PM
-- Server version: 8.4.3
-- PHP Version: 8.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `showroom_mobil`
--

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int NOT NULL,
  `nama_mobil` varchar(100) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `harga` decimal(15,2) NOT NULL,
  `deskripsi` text,
  `gambar` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `nama_mobil`, `kategori`, `harga`, `deskripsi`, `gambar`, `created_at`) VALUES
(1, 'Rolls-Royce Phantom', 'Luxury Sedan', 20000000000.00, 'Kemewahan tertinggi di atas roda dengan kenyamanan kabin layaknya istana berjalan.', '6abc3bf7c60fd.jpg', '2026-09-29 20:49:42'),
(2, 'Lamborghini Aventador SVJ', 'Supercar', 12500000000.00, 'Performa buas V12 dengan aerodinamika agresif untuk sensasi balap sejati.', '6abc3b667fa48.jpg', '2026-09-29 20:49:42'),
(6, 'Ferrari SF90 Stradale', 'Supercar', 10000000000.00, 'Mobil plug-in hybrid berperforma tinggi pertama dari Ferrari yang menggabungkan mesin V8 turbo dengan tiga motor listrik bertenaga total 1.000 tenaga kuda.', '6abc3cbf19484.jpg', '2026-09-29 22:33:35'),
(7, 'Bugatti Chiron Sport', 'Supercar', 45000000000.00, 'Mahakarya kecepatan dunia dengan mesin W16 quad-turbocharged menghasilkan 1.500 tenaga kuda, dirancang khusus untuk kecepatan ekstrem dan kemewahan absolut.', '6abc3d5d41744.jpg', '2026-09-29 22:36:13'),
(8, 'Aston Martin DBS Superleggera', 'Supercar', 95000000000.00, 'Perpaduan sempurna antara keanggunan desain Inggris klasik dan tenaga buas mesin V12 twin-turbo yang siap meluncur dengan kestabilan paripurna.', '6abc3de271397.jpg', '2026-09-29 22:38:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') DEFAULT 'customer',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'VVIP Admin', 'admin@showroom.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '2026-09-29 20:49:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
