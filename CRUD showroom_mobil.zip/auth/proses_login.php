<?php
// Logika pemrosesan login alternatif jika diperlukan terpisah dari login.php
session_start();
include '../config/database.php';
// Handler logika jika form action mengarah kesini.
header("Location: login.php");
exit;