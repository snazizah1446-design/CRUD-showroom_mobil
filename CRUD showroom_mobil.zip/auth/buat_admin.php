<?php
include '../config/database.php';
$success = ''; $error = '';

// Proses Hapus Akun
if (isset($_GET['hapus_id'])) {
    $hapus_id = intval($_GET['hapus_id']);
    mysqli_query($conn, "DELETE FROM users WHERE id = $hapus_id");
    header("Location: buat_admin.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'customer';

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
    if (mysqli_num_rows($check) > 0) {
        $error = "Email sudah terdaftar!";
    } else {
        $query = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', '$role')";
        if (mysqli_query($conn, $query)) {
            $success = "Akun berhasil dibuat! Silakan <a href='login.php' class='text-amber-400 underline'>Login</a>";
        } else {
            $error = "Terjadi kesalahan.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Registrasi & Manajemen Akun - VVIP Showroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-[#0b0c10] text-gray-200 p-8 min-h-screen flex flex-col items-center justify-center">
    <div class="bg-[#1f2833] p-8 rounded-2xl shadow-2xl w-full max-w-xl border border-gray-800 mb-8">
        <h2 class="text-3xl font-bold text-white text-center mb-6">VVIP <span class="text-amber-400">REGISTER</span></h2>
        
        <?php if ($error): ?><div class="bg-red-500/15 border border-red-500 text-red-400 p-3 rounded-lg mb-4 text-sm text-center"><?= $error ?></div><?php endif; ?>
        <?php if ($success): ?><div class="bg-green-500/15 border border-green-500 text-green-400 p-3 rounded-lg mb-4 text-sm text-center"><?= $success ?></div><?php endif; ?>
        
        <form action="" method="POST" class="space-y-4">
            <div>
                <label class="block text-sm font-medium mb-1">Username</label>
                <input type="text" name="username" required autocomplete="off" class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white focus:border-amber-400 outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Email</label>
                <input type="email" name="email" required autocomplete="off" class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white focus:border-amber-400 outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Password</label>
                <div class="relative">
                    <input type="password" name="password" id="regPassword" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white focus:border-amber-400 outline-none pr-10">
                    <button type="button" onclick="toggleRegPassword()" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-amber-400 focus:outline-none">
                        <i id="regEyeIcon" class="fa-solid fa-eye-slash"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="w-full bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold py-2 rounded-lg transition">Daftar Akun</button>
        </form>
        <p class="text-center text-sm text-gray-400 mt-6">Sudah punya akun? <a href="login.php" class="text-amber-400 hover:underline">Login di sini</a></p>
    </div>

    <!-- Tabel Manajemen / Hapus Akun Terdaftar -->
    <div class="bg-[#1f2833] p-6 rounded-2xl shadow-xl border border-gray-800 w-full max-w-xl">
        <h3 class="text-lg font-bold text-white mb-4 border-l-4 border-amber-400 pl-3">Manajemen Akun Terdaftar</h3>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
                <thead>
                    <tr class="bg-gray-900 text-gray-400 border-b border-gray-800">
                        <th class="p-3">Username</th>
                        <th class="p-3">Email</th>
                        <th class="p-3">Role</th>
                        <th class="p-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-800">
                    <?php
                    $users = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
                    while ($u = mysqli_fetch_assoc($users)) {
                        ?>
                        <tr class="hover:bg-gray-800/40">
                            <td class="p-3 font-semibold text-white"><?= htmlspecialchars($u['username']) ?></td>
                            <td class="p-3 text-gray-300"><?= htmlspecialchars($u['email']) ?></td>
                            <td class="p-3"><span class="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded text-xs font-bold"><?= $u['role'] ?></span></td>
                            <td class="p-3 text-center">
                                <a href="buat_admin.php?hapus_id=<?= $u['id'] ?>" onclick="return confirm('Yakin ingin menghapus akun ini?')" class="text-red-400 hover:underline font-semibold">Hapus</a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function toggleRegPassword() {
            const pwdInput = document.getElementById('regPassword');
            const eyeIcon = document.getElementById('regEyeIcon');
            if (pwdInput.type === 'password') {
                pwdInput.type = 'text';
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            } else {
                pwdInput.type = 'password';
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            }
        }
    </script>
</body>
</html>