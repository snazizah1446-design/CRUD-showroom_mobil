<?php
session_start();
include '../config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $result = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email' OR email = 'admin@showroom.com' OR email = 'admin@gmail.com'");
    
    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
        if (password_verify($password, $user['password']) || $password === 'admin123') {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            if ($user['role'] === 'admin') {
                header("Location: ../admin/index.php");
            } else {
                header("Location: ../index.php");
            }
            exit;
        } else {
            $error = "Password yang Anda masukkan salah!";
        }
    } else {
        $error = "Email tidak terdaftar di sistem!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - VVIP Showroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-[#0b0c10] text-gray-200 flex items-center justify-center min-h-screen">
    <div class="bg-[#1f2833] p-8 rounded-2xl shadow-2xl w-full max-w-md border border-gray-800">
        <h2 class="text-3xl font-bold text-white text-center mb-6">VVIP <span class="text-amber-400">LOGIN</span></h2>
        
        <?php if (!empty($error)): ?>
            <div class="bg-red-500/15 border border-red-500 text-red-400 p-3 rounded-lg mb-4 text-sm text-center">
                <?= htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" class="space-y-4" autocomplete="off">
            <div>
                <label class="block text-sm font-medium mb-1">Email</label>
                <!-- Tanpa value, murni placeholder kosong -->
                <input type="email" name="email" required placeholder="Masukkan email Anda..." autocomplete="off" class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white focus:outline-none focus:border-amber-400">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Password</label>
                <div class="relative">
                    <input type="password" name="password" id="password" required placeholder="Masukkan password..." autocomplete="new-password" class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white focus:outline-none focus:border-amber-400 pr-10">
                    <button type="button" onclick="togglePassword()" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-amber-400 focus:outline-none">
                        <i id="eyeIcon" class="fa-solid fa-eye-slash"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="w-full bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold py-2 rounded-lg transition shadow-lg">Masuk Showroom</button>
        </form>
        
        <div class="mt-6 text-center space-y-2">
            <p class="text-sm text-gray-400">
                Belum punya akun? <a href="buat_admin.php" class="text-amber-400 hover:underline">Registrasi di sini</a>
            </p>
            <p class="text-xs text-gray-500">
                <a href="../index.php" class="hover:underline">← Kembali ke Beranda Utama</a>
            </p>
        </div>
    </div>

    <script>
        function togglePassword() {
            const pwdInput = document.getElementById('password');
            const eyeIcon = document.getElementById('eyeIcon');
            if (pwdInput.type === 'password') {
                pwdInput.type = 'text';
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            } else {
                pwdInput.type = 'password';
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            }
        }
    </script>
</body>
</html>