<?php 
include 'includes/header.php';
include 'config/database.php';
?>
<main class="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
    <h2 class="text-3xl font-bold text-white mb-8 border-l-4 border-amber-400 pl-3">Katalog Lengkap Showroom</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <?php
        $result = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $img_path = "uploads/produk/" . $row['gambar'];
                ?>
                <div class="bg-[#1f2833] rounded-xl overflow-hidden shadow-xl border border-gray-800 flex flex-col justify-between">
                    <div>
                        <div class="h-48 bg-gray-700 flex items-center justify-center relative overflow-hidden">
                            <?php if (!empty($row['gambar']) && file_exists($img_path)): ?>
                                <img src="<?= htmlspecialchars($img_path) ?>" alt="<?= htmlspecialchars($row['nama_mobil']) ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <i class="fa-solid fa-car text-5xl text-gray-500"></i>
                            <?php endif; ?>
                            <span class="absolute top-2 right-2 bg-amber-500 text-gray-900 text-xs font-bold px-2 py-1 rounded z-10"><?= htmlspecialchars($row['kategori']) ?></span>
                        </div>
                        <div class="p-5">
                            <h3 class="text-xl font-bold text-white mb-2"><?= htmlspecialchars($row['nama_mobil']) ?></h3>
                            <p class="text-gray-400 text-sm mb-4 line-clamp-2"><?= htmlspecialchars($row['deskripsi']) ?></p>
                        </div>
                    </div>
                    <div class="p-5 pt-0 flex items-center justify-between border-t border-gray-700/50 mt-4">
                        <span class="text-amber-400 font-bold text-sm">Rp <?= number_format($row['harga'], 0, ',', '.') ?></span>
                        <a href="detail.php?id=<?= $row['id'] ?>" class="bg-amber-500 hover:bg-amber-600 text-gray-900 font-semibold px-3 py-2 rounded-lg text-xs transition">Detail</a>
                    </div>
                </div>
                <?php
            }
        } else {
            echo '<p class="text-gray-400 col-span-full text-center py-10">Belum ada unit mobil tersedia di showroom.</p>';
        }
        ?>
    </div>
</main>
<?php include 'includes/footer.php'; ?>