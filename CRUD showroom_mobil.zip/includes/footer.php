<footer class="bg-[#1f2833] border-t border-gray-800 py-6 mt-12 text-center text-sm text-gray-400">
        <p>&copy; 2026 VVIP Showroom Mobil Mewah. All Rights Reserved.</p>
    </footer>
</body>
</html>