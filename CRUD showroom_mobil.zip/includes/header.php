<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VVIP Showroom Mobil Mewah</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="bg-[#0b0c10] text-gray-200 min-h-screen flex flex-col font-sans">
    <header class="bg-[#1f2833] border-b border-gray-800 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <i class="fa-solid fa-car-rear text-amber-400 text-3xl"></i>
                <a href="index.php" class="text-2xl font-bold tracking-wider text-white">VVIP<span class="text-amber-400">SHOWROOM</span></a>
            </div>
            <nav class="hidden md:flex items-center space-x-8 font-medium">
                <a href="index.php" class="hover:text-amber-400 transition">Katalog</a>
                <a href="produk.php" class="hover:text-amber-400 transition">Daftar Unit</a>
                <a href="tentang.php" class="hover:text-amber-400 transition">Tentang Kami</a>
            </nav>
            <div class="flex items-center space-x-4">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span class="text-sm text-gray-300">Halo, <strong class="text-amber-400"><?= htmlspecialchars($_SESSION['username']); ?></strong></span>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <a href="admin/index.php" class="bg-amber-500 hover:bg-amber-600 text-gray-900 px-3 py-2 rounded-lg text-xs font-bold transition">Admin Panel</a>
                    <?php endif; ?>
                    <a href="logout.php" class="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-lg text-xs font-semibold transition">Logout</a>
                <?php else: ?>
                    <a href="auth/login.php" class="text-gray-300 hover:text-white px-3 py-2 text-sm font-semibold transition">Login</a>
                    <a href="auth/login.php" class="bg-amber-500 hover:bg-amber-600 text-gray-900 px-4 py-2 rounded-lg text-sm font-bold transition">Registrasi</a>
                <?php endif; ?>
            </div>
        </div>
    </header>