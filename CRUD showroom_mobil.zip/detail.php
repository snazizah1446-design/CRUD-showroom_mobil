<?php 
include 'includes/header.php';
include 'config/database.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
$car = mysqli_fetch_assoc($query);

if (!$car) {
    echo "<script>alert('Unit mobil tidak ditemukan!'); window.location='produk.php';</script>";
    exit;
}

$img_path = "uploads/produk/" . $car['gambar'];
?>
<main class="flex-grow max-w-5xl mx-auto px-4 py-12 w-full">
    <div class="bg-[#1f2833] border border-gray-800 rounded-2xl overflow-hidden shadow-2xl grid grid-cols-1 md:grid-cols-2 gap-8 p-8">
        <div class="h-80 bg-gray-700 rounded-xl flex items-center justify-center relative overflow-hidden">
            <?php if (!empty($car['gambar']) && file_exists($img_path)): ?>
                <img src="<?= htmlspecialchars($img_path) ?>" alt="<?= htmlspecialchars($car['nama_mobil']) ?>" class="w-full h-full object-cover">
            <?php else: ?>
                <i class="fa-solid fa-car text-7xl text-gray-500"></i>
            <?php endif; ?>
            <span class="absolute top-4 right-4 bg-amber-500 text-gray-950 font-bold px-3 py-1 rounded text-sm z-10"><?= htmlspecialchars($car['kategori']) ?></span>
        </div>
        <div class="flex flex-col justify-between">
            <div>
                <h1 class="text-3xl font-extrabold text-white mb-4"><?= htmlspecialchars($car['nama_mobil']) ?></h1>
                <p class="text-2xl font-bold text-amber-400 mb-6">Rp <?= number_format($car['harga'], 0, ',', '.') ?></p>
                <h3 class="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Spesifikasi & Deskripsi</h3>
                <p class="text-gray-300 leading-relaxed mb-6"><?= htmlspecialchars($car['deskripsi']) ?></p>
            </div>
            <button onclick="alert('Permintaan test drive / pemesanan unit terkirim. Konsultan VVIP kami akan segera menghubungi Anda.')" class="w-full bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold py-3 rounded-xl transition shadow-lg">
                Booking Test Drive / Pesan Unit
            </button>
        </div>
    </div>
</main>
<?php include 'includes/footer.php'; ?>