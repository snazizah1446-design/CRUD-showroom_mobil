<?php
include '../includes/auth.php';
check_admin();
include '../config/database.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id > 0) {
    mysqli_query($conn, "DELETE FROM produk WHERE id = $id");
}
header("Location: produk.php");
exit;
?>