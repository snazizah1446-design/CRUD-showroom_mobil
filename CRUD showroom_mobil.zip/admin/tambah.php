<?php
include '../includes/auth.php';
check_admin();
include '../config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_mobil = mysqli_real_escape_string($conn, $_POST['nama_mobil']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $harga = floatval($_POST['harga']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);

    $nama_file = $_FILES['gambar']['name'];
    $ukuran_file = $_FILES['gambar']['size'];
    $error_file = $_FILES['gambar']['error'];
    $tmp_name = $_FILES['gambar']['tmp_name'];

    if ($error_file === 4) {
        $error = "Pilih file gambar terlebih dahulu!";
    } else {
        $ekstensi_valid = ['jpg', 'jpeg', 'png', 'webp'];
        $ekstensi_file = explode('.', $nama_file);
        $ekstensi_file = strtolower(end($ekstensi_file));

        if (!in_array($ekstensi_file, $ekstensi_valid)) {
            $error = "Format file tidak valid! Gunakan JPG, JPEG, PNG, atau WEBP.";
        } else {
            $nama_file_baru = uniqid() . '.' . $ekstensi_file;
            $target_dir = "../uploads/produk/";
            
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            if (move_uploaded_file($tmp_name, $target_dir . $nama_file_baru)) {
                $query = "INSERT INTO produk (nama_mobil, kategori, harga, deskripsi, gambar) VALUES ('$nama_mobil', '$kategori', $harga, '$deskripsi', '$nama_file_baru')";
                if (mysqli_query($conn, $query)) {
                    header("Location: produk.php");
                    exit;
                } else {
                    $error = "Gagal menyimpan ke database.";
                }
            } else {
                $error = "Gagal mengunggah file gambar.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Unit - Admin VVIP</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0b0c10] text-gray-200 p-8 max-w-2xl mx-auto min-h-screen flex items-center">
    <div class="bg-[#1f2833] p-8 rounded-2xl shadow-xl border border-gray-800 w-full">
        <h2 class="text-2xl font-bold text-white mb-6">Tambah Unit Mobil Baru</h2>
        
        <?php if (!empty($error)): ?>
            <div class="bg-red-500/15 border border-red-500 text-red-400 p-3 rounded-lg mb-4 text-sm text-center">
                <?= $error; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label class="block text-sm font-medium mb-1">Nama Mobil</label>
                <input type="text" name="nama_mobil" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Kategori (Contoh: Hypercar / Supercar)</label>
                <input type="text" name="kategori" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Harga (IDR)</label>
                <input type="number" step="0.01" name="harga" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Upload File Gambar</label>
                <input type="file" name="gambar" accept="image/*" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400 text-sm file:mr-4 file:py-1 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-amber-500 file:text-gray-900 hover:file:bg-amber-600">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Deskripsi Spesifikasi</label>
                <textarea name="deskripsi" rows="4" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400"></textarea>
            </div>
            <div class="flex space-x-4 pt-4">
                <button type="submit" class="flex-grow bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold py-2 rounded-lg transition">Simpan Unit</button>
                <a href="produk.php" class="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg text-center font-semibold transition">Batal</a>
            </div>
        </form>
    </div>
</body>
</html>