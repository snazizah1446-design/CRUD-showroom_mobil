<?php
include '../includes/auth.php';
check_admin();
include '../config/database.php';

$total_produk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM produk"))['total'];
$total_user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users"))['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - VVIP Showroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-[#0b0c10] text-gray-200 flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-[#1f2833] border-r border-gray-800 flex flex-col justify-between hidden md:flex">
        <div class="p-6">
            <h1 class="text-xl font-bold text-white mb-8">VVIP <span class="text-amber-400">ADMIN</span></h1>
            <nav class="space-y-2">
                <a href="index.php" class="block py-2.5 px-4 rounded-lg bg-amber-500 text-gray-900 font-bold"><i class="fa-solid fa-chart-pie mr-2"></i> Dashboard</a>
                <a href="produk.php" class="block py-2.5 px-4 rounded-lg hover:bg-gray-800 text-gray-300 transition"><i class="fa-solid fa-car mr-2"></i> Kelola Mobil</a>
                <a href="../index.php" class="block py-2.5 px-4 rounded-lg hover:bg-gray-800 text-gray-300 transition"><i class="fa-solid fa-house mr-2"></i> Lihat Website</a>
            </nav>
        </div>
        <div class="p-6 border-t border-gray-800">
            <a href="logout.php" class="block py-2 px-4 bg-red-600 hover:bg-red-700 text-white rounded-lg text-center font-semibold transition">Logout</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-grow p-8">
        <h2 class="text-3xl font-bold text-white mb-6">Dashboard Overview</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-[#1f2833] p-6 rounded-xl border border-gray-800">
                <h3 class="text-gray-400 text-sm font-semibold">Total Unit Mobil</h3>
                <p class="text-4xl font-extrabold text-amber-400 mt-2"><?= $total_produk ?></p>
            </div>
            <div class="bg-[#1f2833] p-6 rounded-xl border border-gray-800">
                <h3 class="text-gray-400 text-sm font-semibold">Total Pengguna Terdaftar</h3>
                <p class="text-4xl font-extrabold text-amber-400 mt-2"><?= $total_user ?></p>
            </div>
        </div>
    </main>
</body>
</html>