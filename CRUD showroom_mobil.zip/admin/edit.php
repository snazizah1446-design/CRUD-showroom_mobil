<?php
include '../includes/auth.php';
check_admin();
include '../config/database.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$result = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
$car = mysqli_fetch_assoc($result);

if (!$car) {
    header("Location: produk.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_mobil = mysqli_real_escape_string($conn, $_POST['nama_mobil']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $harga = floatval($_POST['harga']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $gambar_lama = $car['gambar'];

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] !== 4) {
        $nama_file = $_FILES['gambar']['name'];
        $tmp_name = $_FILES['gambar']['tmp_name'];
        
        $ekstensi_valid = ['jpg', 'jpeg', 'png', 'webp'];
        $ekstensi_file = explode('.', $nama_file);
        $ekstensi_file = strtolower(end($ekstensi_file));

        if (!in_array($ekstensi_file, $ekstensi_valid)) {
            $error = "Format file tidak valid!";
        } else {
            $nama_file_baru = uniqid() . '.' . $ekstensi_file;
            $target_dir = "../uploads/produk/";

            if (move_uploaded_file($tmp_name, $target_dir . $nama_file_baru)) {
                if (!empty($gambar_lama) && file_exists($target_dir . $gambar_lama)) {
                    unlink($target_dir . $gambar_lama);
                }
                $gambar_lama = $nama_file_baru;
            } else {
                $error = "Gagal mengunggah gambar baru.";
            }
        }
    }

    if (empty($error)) {
        $query = "UPDATE produk SET nama_mobil='$nama_mobil', kategori='$kategori', harga=$harga, deskripsi='$deskripsi', gambar='$gambar_lama' WHERE id=$id";
        if (mysqli_query($conn, $query)) {
            header("Location: produk.php");
            exit;
        } else {
            $error = "Gagal memperbarui database.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Unit - Admin VVIP</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0b0c10] text-gray-200 p-8 max-w-2xl mx-auto min-h-screen flex items-center">
    <div class="bg-[#1f2833] p-8 rounded-2xl shadow-xl border border-gray-800 w-full">
        <h2 class="text-2xl font-bold text-white mb-6">Edit Unit Mobil</h2>
        
        <?php if (!empty($error)): ?>
            <div class="bg-red-500/15 border border-red-500 text-red-400 p-3 rounded-lg mb-4 text-sm text-center">
                <?= $error; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label class="block text-sm font-medium mb-1">Nama Mobil</label>
                <input type="text" name="nama_mobil" value="<?= htmlspecialchars($car['nama_mobil']) ?>" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Kategori</label>
                <input type="text" name="kategori" value="<?= htmlspecialchars($car['kategori']) ?>" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Harga (IDR)</label>
                <input type="number" step="0.01" name="harga" value="<?= $car['harga'] ?>" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Ganti File Gambar (Opsional)</label>
                <?php if (!empty($car['gambar'])): ?>
                    <p class="text-xs text-gray-400 mb-2">File saat ini: <span class="text-amber-400"><?= htmlspecialchars($car['gambar']) ?></span></p>
                <?php endif; ?>
                <input type="file" name="gambar" accept="image/*" class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400 text-sm file:mr-4 file:py-1 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-amber-500 file:text-gray-900 hover:file:bg-amber-600">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Deskripsi Spesifikasi</label>
                <textarea name="deskripsi" rows="4" required class="w-full px-4 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white outline-none focus:border-amber-400"><?= htmlspecialchars($car['deskripsi']) ?></textarea>
            </div>
            <div class="flex space-x-4 pt-4">
                <button type="submit" class="flex-grow bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold py-2 rounded-lg transition">Perbarui Unit</button>
                <a href="produk.php" class="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg text-center font-semibold transition">Batal</a>
            </div>
        </form>
    </div>
</body>
</html>