<?php
include '../includes/auth.php';
check_admin();
include '../config/database.php';
// Handler logika pemrosesan tambahan untuk produk admin jika diperlukan.
header("Location: produk.php");
exit;
?>