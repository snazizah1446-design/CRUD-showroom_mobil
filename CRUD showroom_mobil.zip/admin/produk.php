<?php
include '../includes/auth.php';
check_admin();
include '../config/database.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Mobil - Admin VVIP</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-[#0b0c10] text-gray-200 flex min-h-screen">
    <aside class="w-64 bg-[#1f2833] border-r border-gray-800 flex flex-col justify-between hidden md:flex">
        <div class="p-6">
            <h1 class="text-xl font-bold text-white mb-8">VVIP <span class="text-amber-400">ADMIN</span></h1>
            <nav class="space-y-2">
                <a href="index.php" class="block py-2.5 px-4 rounded-lg hover:bg-gray-800 text-gray-300 transition">Dashboard</a>
                <a href="produk.php" class="block py-2.5 px-4 rounded-lg bg-amber-500 text-gray-900 font-bold">Kelola Mobil</a>
                <a href="../index.php" class="block py-2.5 px-4 rounded-lg hover:bg-gray-800 text-gray-300 transition">Lihat Website</a>
            </nav>
        </div>
        <div class="p-6 border-t border-gray-800">
            <a href="logout.php" class="block py-2 px-4 bg-red-600 hover:bg-red-700 text-white rounded-lg text-center font-semibold transition">Logout</a>
        </div>
    </aside>

    <main class="flex-grow p-8">
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-3xl font-bold text-white">Daftar Unit Showroom</h2>
            <a href="tambah.php" class="bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold px-4 py-2 rounded-lg text-sm transition">+ Tambah Unit</a>
        </div>
        <div class="bg-[#1f2833] rounded-xl border border-gray-800 overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-900 text-gray-400 text-sm border-b border-gray-800">
                        <th class="p-4">Pratinjau</th>
                        <th class="p-4">Nama Mobil</th>
                        <th class="p-4">Kategori</th>
                        <th class="p-4">Harga</th>
                        <th class="p-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-800">
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $img_path = "../uploads/produk/" . $row['gambar'];
                            ?>
                            <tr class="hover:bg-gray-800/50">
                                <td class="p-4 w-20">
                                    <div class="w-16 h-12 bg-gray-700 rounded overflow-hidden flex items-center justify-center">
                                        <?php if (!empty($row['gambar']) && file_exists($img_path)): ?>
                                            <img src="<?= htmlspecialchars($img_path) ?>" alt="" class="w-full h-full object-cover">
                                        <?php else: ?>
                                            <i class="fa-solid fa-car text-gray-400"></i>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="p-4 font-semibold text-white"><?= htmlspecialchars($row['nama_mobil']) ?></td>
                                <td class="p-4"><span class="bg-amber-500/10 text-amber-400 px-2 py-1 rounded text-xs font-bold"><?= htmlspecialchars($row['kategori']) ?></span></td>
                                <td class="p-4 text-amber-400 font-bold">Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                                <td class="p-4 text-center space-x-2">
                                    <a href="edit.php?id=<?= $row['id'] ?>" class="text-blue-400 hover:underline text-sm font-semibold">Edit</a>
                                    <a href="hapus.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus unit ini?')" class="text-red-400 hover:underline text-sm font-semibold">Hapus</a>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo '<tr><td colspan="5" class="p-6 text-center text-gray-400">Belum ada unit terdaftar.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>