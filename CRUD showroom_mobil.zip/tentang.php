<?php include 'includes/header.php'; ?>
<main class="flex-grow max-w-4xl mx-auto px-4 py-16 text-center">
    <h1 class="text-4xl font-extrabold text-white mb-6">Tentang VVIP Showroom</h1>
    <p class="text-gray-300 text-lg leading-relaxed mb-8">
        VVIP Showroom adalah diler kendaraan mewah terkemuka yang menghadirkan mobil-mobil eksklusif berstandar internasional, mulai dari Hypercar, Supercar, hingga Luxury Sedan bagi para kolektor dan penikmat otomotif sejati di Indonesia.
    </p>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
        <div class="bg-[#1f2833] p-6 rounded-xl border border-gray-800">
            <i class="fa-solid fa-shield-halved text-amber-400 text-3xl mb-4"></i>
            <h3 class="text-xl font-bold text-white mb-2">Keaslian Terjamin</h3>
            <p class="text-gray-400 text-sm">Setiap unit dilengkapi sertifikasi resmi pabrikan dunia.</p>
        </div>
        <div class="bg-[#1f2833] p-6 rounded-xl border border-gray-800">
            <i class="fa-solid fa-handshake text-amber-400 text-3xl mb-4"></i>
            <h3 class="text-xl font-bold text-white mb-2">Layanan VVIP Personal</h3>
            <p class="text-gray-400 text-sm">Konsultan pribadi siap melayani pengiriman langsung ke garasi Anda.</p>
        </div>
        <div class="bg-[#1f2833] p-6 rounded-xl border border-gray-800">
            <i class="fa-solid fa-award text-amber-400 text-3xl mb-4"></i>
            <h3 class="text-xl font-bold text-white mb-2">Reputasi Global</h3>
            <p class="text-gray-400 text-sm">Dipercaya oleh pesohor dan kolektor mobil mewah.</p>
        </div>
    </div>
</main>
<?php include 'includes/footer.php'; ?>